
import { useEffect, useState } from "react";
import { BrowserRouter, NavLink, Route, Routes } from "react-router-dom";
import "./App.css";

const menuItems = [
  { name: "Dashboard", icon: "⌂", path: "/" },
  { name: "Explore Campus", icon: "▦", path: "/explore" },
  { name: "AI Chatbot", icon: "✧", path: "/chatbot" },
  { name: "Appointments", icon: "▣", path: "/appointments" },
  { name: "Campus Info", icon: "ⓘ", path: "/campus-info" },
  { name: "3D Campus", icon: "◇", path: "/3d-campus" },
  { name: "Notifications", icon: "♧", path: "/notifications" },
  { name: "Settings", icon: "⚙", path: "/settings" },
];

const locations = [
  {
    id: "academic-block",
    name: "Academic Block",
    category: "Academic",
    icon: "🏛",
    location: "Main Campus",
    room: "Multiple classrooms",
    floor: "Multiple floors",
    facilities: ["Classrooms", "Academic departments", "Faculty offices"],
    directions: ["Enter through the main campus entrance.", "Continue toward the central campus area.", "Follow the Academic Block signs."],
    description: "Explore academic departments, classrooms and faculty offices.",
    details: "The Academic Block is a central study area for teaching, learning and academic activities. Confirm room-level information with official university records.",
  },
  {
    id: "cs-lab",
    name: "Computer Science Lab",
    category: "Labs",
    icon: "💻",
    location: "Academic Block",
    room: "Room number to be confirmed",
    floor: "To be confirmed",
    facilities: ["Computers", "Programming practicals", "Software tools (subject to availability)"],
    directions: ["Go to the Academic Block.", "Check the department or room directory for the lab room.", "Follow the campus signs or ask the information desk if needed."],
    description: "Find programming labs and practical learning spaces.",
    details: "A practical learning space for computing courses. The exact room number, equipment and opening hours must be confirmed from official university records.",
  },
  {
    id: "library",
    name: "University Library",
    category: "Facilities",
    icon: "📚",
    location: "Main Campus",
    room: "Room / block to be confirmed",
    floor: "To be confirmed",
    facilities: ["Study resources", "Reading area (confirm locally)", "Library services (confirm locally)"],
    directions: ["Enter the main campus.", "Look for the official library sign or campus directory.", "Check the library desk for current opening hours."],
    description: "Discover library facilities and study resources.",
    details: "A place to access study resources and library services. Please verify the building location, opening hours and available services with the university.",
  },
  {
    id: "admin-office",
    name: "Administration Office",
    category: "Offices",
    icon: "🏢",
    location: "Administration Block",
    room: "Room number to be confirmed",
    floor: "To be confirmed",
    facilities: ["Administrative enquiries", "Student support (confirm locally)", "Official documentation (confirm locally)"],
    directions: ["Locate the Administration Block using the campus directory.", "Enter the block and check the office directory.", "Ask reception to confirm the correct counter or room."],
    description: "Find administrative services and university offices.",
    details: "For administrative queries, verify the responsible office, contact details and working hours through official university information.",
  },
  {
    id: "faculty-offices",
    name: "Faculty Offices",
    category: "Offices",
    icon: "👩‍🏫",
    location: "Academic Block",
    room: "Depends on department",
    floor: "To be confirmed",
    facilities: ["Faculty directory (if available)", "Office-hour information (confirm locally)", "Appointment enquiries"],
    directions: ["Go to the relevant academic department.", "Check the department's faculty or room directory.", "Confirm the teacher's availability before visiting."],
    description: "Find faculty offices and teacher appointment information.",
    details: "Teacher names, office numbers and appointment availability should be linked to the official faculty directory when it is available.",
  },
  {
    id: "cafeteria",
    name: "Cafeteria",
    category: "Facilities",
    icon: "☕",
    location: "Student Area",
    room: "Not applicable",
    floor: "To be confirmed",
    facilities: ["Refreshments (confirm locally)", "Student seating (confirm locally)"],
    directions: ["Use the campus directory to locate the student area.", "Follow cafeteria signs.", "Check posted timings before planning a visit."],
    description: "Locate the cafeteria and student refreshment area.",
    details: "Cafeteria location, menu, opening hours and facilities should be confirmed from current campus information.",
  },
];

const categories = ["All Locations", "Academic", "Labs", "Offices", "Facilities"];

const events = [
  { day: "25", month: "Oct", title: "University Seminar", time: "10:00 AM" },
  { day: "27", month: "Oct", title: "Career Guidance", time: "11:00 AM" },
  { day: "30", month: "Oct", title: "Campus Activities", time: "09:00 AM" },
];

function SplashScreen() {
  return (
    <div className="splash">
      <div className="splash-logo">🏛</div>
      <h1>AI-Powered Virtual Campus</h1>
      <p>Explore · Learn · Connect</p>
      <div className="spinner" />
      <small>Preparing your campus experience...</small>
    </div>
  );
}

function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-logo">🏛</div>
        <h2>AI-Powered<br />Virtual Campus</h2>
        <p>Your smart university guide</p>
      </div>

      <nav className="nav-menu">
        {menuItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            end={item.path === "/"}
            className={({ isActive }) =>
              `nav-link ${isActive ? "selected" : ""}`
            }
          >
            <span className="nav-icon">{item.icon}</span>
            <span>{item.name}</span>
          </NavLink>
        ))}
      </nav>

      <div className="sidebar-footer">
        <div>🏛</div>
        <p>Explore · Learn · Grow</p>
      </div>
    </aside>
  );
}

function Header() {
  const [search, setSearch] = useState("");
  const [notice, setNotice] = useState("");

  function handleSearch(event) {
    event.preventDefault();
    const query = search.trim();

    if (!query) {
      setNotice("Please enter a campus location to search.");
      return;
    }

    window.dispatchEvent(
      new CustomEvent("campus-search", { detail: query })
    );
    window.location.href = `/explore?q=${encodeURIComponent(query)}`;
  }

  return (
    <header className="topbar">
      <form className="header-search" onSubmit={handleSearch}>
        <span className="search-icon">⌕</span>
        <input
          value={search}
          onChange={(event) => {
            setSearch(event.target.value);
            setNotice("");
          }}
          placeholder="Search campus information..."
          aria-label="Search campus information"
        />
        <button type="submit">Search</button>
      </form>

      <div className="visitor">
        <div className="visitor-avatar">🎓</div>
        <div>
          <strong>Campus Visitor</strong>
          <small>Public Access</small>
        </div>
      </div>

      {notice && <span className="search-notice">{notice}</span>}
    </header>
  );
}

function Dashboard() {
  const stats = [
    { icon: "🎓", title: "Explore", label: "Academic Departments", tone: "lavender" },
    { icon: "👥", title: "Discover", label: "Campus Community", tone: "blue" },
    { icon: "🏛", title: "Explore", label: "Campus Facilities", tone: "green" },
    { icon: "▦", title: "Find", label: "University Events", tone: "peach" },
  ];

  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">WELCOME TO YOUR UNIVERSITY</span>
          <h1>AI-Powered<br />Virtual Campus 🎓</h1>
          <p>
            Your smart way to explore, learn and connect with our university.
          </p>
          <NavLink to="/explore" className="primary-button">
            Explore Campus <span>→</span>
          </NavLink>
        </div>
        <div className="hero-art" aria-hidden="true">🏛</div>
      </section>

      <section className="stats-grid">
        {stats.map((stat) => (
          <article className={`stat-card ${stat.tone}`} key={stat.label}>
            <div className="stat-icon">{stat.icon}</div>
            <div>
              <h2>{stat.title}</h2>
              <p>{stat.label}</p>
            </div>
          </article>
        ))}
      </section>

      <section className="dashboard-grid">
        <article className="panel overview-panel">
          <div className="panel-heading">
            <h2>🏛 Campus Overview</h2>
            <NavLink to="/campus-info">View details →</NavLink>
          </div>

          <div className="overview-body">
            <div className="campus-illustration" aria-label="Illustration of a university building">
              <span className="sun">☀</span>
              <div className="building">
                <div className="building-roof" />
                <div className="building-windows">
                  {Array.from({ length: 12 }, (_, index) => (
                    <span key={index} />
                  ))}
                </div>
                <div className="building-door" />
              </div>
              <div className="lawn" />
            </div>

            <div className="overview-text">
              <p>
                Discover academic spaces, campus facilities and useful
                information to find your way around the university.
              </p>
              {["Classrooms & Labs", "Library & Study Areas", "Student Facilities"].map(
                (item) => (
                  <div className="feature" key={item}>
                    <span>✓</span>{item}
                  </div>
                )
              )}
            </div>
          </div>
        </article>

        <article className="panel events-panel">
          <div className="panel-heading">
            <h2>▦ Upcoming Events</h2>
            <NavLink to="/notifications">View all →</NavLink>
          </div>

          {events.map((event) => (
            <div className="event-row" key={event.day}>
              <div className="event-date">
                <strong>{event.day}</strong>
                <span>{event.month}</span>
              </div>
              <div className="event-text">
                <strong>{event.title}</strong>
                <small>◷ {event.time}</small>
              </div>
            </div>
          ))}
          <p className="sample-note">
            Sample events — replace with official university information.
          </p>
        </article>

        <article className="panel chatbot-panel">
          <div className="robot-icon">🤖</div>
          <h2>Ask Our AI Chatbot</h2>
          <p>
            Need directions or campus information? Your virtual assistant
            will help you find the right place.
          </p>
          <div className="robot-art">🎓</div>
          <NavLink to="/chatbot" className="chat-button">Chat Now →</NavLink>
        </article>
      </section>

      <section className="bottom-grid">
        <article className="panel quick-panel">
          <h2>⭐ Quick Access</h2>
          <div className="quick-links">
            <NavLink to="/explore"><span>📍</span>Find Location</NavLink>
            <NavLink to="/appointments"><span>▦</span>Appointments</NavLink>
            <NavLink to="/3d-campus"><span>◇</span>Open 3D Campus</NavLink>
            <NavLink to="/campus-info"><span>📚</span>Campus Library</NavLink>
          </div>
        </article>

        <article className="quote-panel">
          <span>“</span>
          <p>A better campus experience,<br />powered by technology.</p>
        </article>
      </section>
    </>
  );
}

function ExploreCampus() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All Locations");
  const [selected, setSelected] = useState([]);
  useEffect(() => {
    const query = new URLSearchParams(window.location.search).get("q") || "";
    setSearch(query);
  }, []);

  const filteredLocations = locations.filter((place) => {
    const matchesCategory =
      category === "All Locations" || place.category === category;
    const query = search.trim().toLowerCase();
    const matchesSearch =
      !query ||
      `${place.name} ${place.category} ${place.location} ${place.description}`
        .toLowerCase()
        .includes(query);

    return matchesCategory && matchesSearch;
  });

  return (
    <section className="explore-page">
      <div className="explore-hero">
        <div className="explore-hero-copy">
          <span className="eyebrow">DISCOVER YOUR UNIVERSITY</span>
          <h1>Explore Campus</h1>
          <p>
            Find buildings, departments, laboratories and facilities
            across your virtual university campus.
          </p>
          <NavLink to="/3d-campus" className="primary-button">
            ◇ Open 3D Campus <span>→</span>
          </NavLink>
        </div>
        <div className="explore-building-art" aria-hidden="true">
          <span className="explore-sun">☀</span>
          <div className="explore-building">
            <div className="explore-roof" />
            <div className="explore-columns">
              <i /><i /><i /><i />
            </div>
            <div className="explore-door" />
          </div>
          <div className="explore-grass" />
        </div>
      </div>

      <div className="explore-heading">
        <div>
          <h2>Campus Locations</h2>
          <p>Search for a place or select a category.</p>
        </div>
        <span className="location-count">
          {filteredLocations.length} locations
        </span>
      </div>

      <div className="explore-search">
        <span>⌕</span>
        <input
          type="search"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search buildings, labs, offices..."
          aria-label="Search campus locations"
        />
        {search && (
          <button
            type="button"
            onClick={() => {
              setSearch("");
              window.history.replaceState({}, "", "/explore");
            }}
          >
            Clear
          </button>
        )}
      </div>

      <div className="category-filters">
        {categories.map((item) => (
          <button
            type="button"
            key={item}
            className={`category-chip ${category === item ? "active" : ""}`}
            onClick={() => setCategory(item)}
          >
            {item}
          </button>
        ))}
      </div>

      <div className="location-grid">
        {filteredLocations.map((place) => (
          <article className="location-card" key={place.name}>
            <div className="location-art">
              <span className="location-icon">{place.icon}</span>
              <span className="location-category">{place.category}</span>
            </div>

            <div className="location-body">
              <h3>{place.name}</h3>
              <p>{place.description}</p>
              <div className="location-meta">📍 {place.location}</div>

              <button
                type="button"
                className="details-button"
                onClick={() =>
                  setSelected((current) =>
                    current.includes(place.name)
                      ? current.filter((name) => name !== place.name)
                      : [...current, place.name]
                  )
                }
              >
                {selected.includes(place.name) ? "Hide Details ↑" : "View Details →"}
              </button>

              {selected.includes(place.name) && (
                <div className="location-detail">
                  <div className="detail-section">
                    <strong>About this location</strong>
                    <p>{place.details}</p>
                  </div>
                  <div className="detail-facts">
                    <div><span>Room</span><strong>{place.room}</strong></div>
                    <div><span>Floor</span><strong>{place.floor}</strong></div>
                    <div><span>Building / Area</span><strong>{place.location}</strong></div>
                  </div>
                  <div className="detail-section">
                    <strong>Facilities</strong>
                    <ul className="detail-list">
                      {place.facilities.map((facility) => <li key={facility}>✓ {facility}</li>)}
                    </ul>
                  </div>
                  <div className="detail-section">
                    <strong>How to find it</strong>
                    <ol className="direction-list">
                      {place.directions.map((step) => <li key={step}>{step}</li>)}
                    </ol>
                  </div>
                  <p className="detail-disclaimer">Room numbers, facilities and directions are placeholders until verified with official campus information.</p>
                  <NavLink to="/3d-campus" className="details-button detail-3d-link">◇ Open 3D Campus (Unity integration planned)</NavLink>
                </div>
              )}
            </div>
          </article>
        ))}
      </div>

      {filteredLocations.length === 0 && (
        <div className="empty-results">
          <span>🔎</span>
          <h3>No locations found</h3>
          <p>Try another search term or choose a different category.</p>
          <button
            type="button"
            className="details-button"
            onClick={() => {
              setSearch("");
              setCategory("All Locations");
            }}
          >
            Show All Locations
          </button>
        </div>
      )}

      <div className="info-note">
        ⓘ <p>
          Locations and descriptions are sample content. Replace them with
          verified university information before your final presentation.
        </p>
      </div>
    </section>
  );
}


const chatbotSuggestions = [
  "Where is the university library?",
  "How can I find the Computer Science Lab?",
  "How do I book a teacher appointment?",
  "What facilities are available on campus?",
];

function getCampusReply(question) {
  const q = question.toLowerCase();

  if (q.includes("library")) {
    return "The University Library is listed under Campus Locations. Open Explore Campus and search for “library”. Its exact building, room and opening hours need to be confirmed with official university information.";
  }
  if (q.includes("lab") || q.includes("computer")) {
    return "You can find the Computer Science Lab in Explore Campus. Search for “Computer Science Lab” to see its current sample details. Please confirm the room number and floor with your department.";
  }
  if (q.includes("appointment") || q.includes("teacher") || q.includes("faculty")) {
    return "To arrange a teacher appointment, contact the relevant department and confirm the teacher’s office hours. Online appointment booking will be connected when the appointment backend is implemented.";
  }
  if (q.includes("facility") || q.includes("facilities") || q.includes("cafeteria")) {
    return "Explore Campus currently lists academic spaces, labs, offices, the library and cafeteria. Some descriptions are sample content, so please verify facilities and timings with the university.";
  }
  if (q.includes("3d") || q.includes("unity") || q.includes("walk")) {
    return "The 3D Campus page is prepared for future Unity integration. The interactive 3D world and character movement are not connected yet.";
  }
  if (q.includes("hello") || q.includes("hi") || q.includes("salam")) {
    return "Hello! Welcome to the AI-Powered Virtual Campus. I can help you find campus locations and explain how to get campus information.";
  }
  return "I can currently answer a few common campus questions using sample campus information. Try asking about the library, computer lab, campus facilities, teacher appointments or the 3D Campus. Live AI answers will be added when the backend is connected.";
}

function Chatbot() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      role: "assistant",
      text: "Hello! 👋 I’m your Campus Assistant. Ask me about campus locations, facilities, teachers or appointments.",
      time: "Now",
    },
  ]);
  const [draft, setDraft] = useState("");

  function sendMessage(text = draft) {
    const cleanText = text.trim();
    if (!cleanText) return;

    const now = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const userMessage = {
      id: Date.now(),
      role: "user",
      text: cleanText,
      time: now,
    };
    const reply = {
      id: Date.now() + 1,
      role: "assistant",
      text: getCampusReply(cleanText),
      time: now,
    };

    setMessages((current) => [...current, userMessage, reply]);
    setDraft("");
  }

  function handleSubmit(event) {
    event.preventDefault();
    sendMessage();
  }

  function clearChat() {
    setMessages([
      {
        id: Date.now(),
        role: "assistant",
        text: "Chat cleared. How can I help you explore the campus?",
        time: "Now",
      },
    ]);
  }

  return (
    <section className="chatbot-page">
      <div className="chatbot-intro">
        <div className="chatbot-intro-icon">🤖</div>
        <div>
          <span className="eyebrow">YOUR DIGITAL CAMPUS GUIDE</span>
          <h1>AI Campus Assistant</h1>
          <p>Ask questions to get started with campus information.</p>
        </div>
        <span className="chatbot-status"><i /> Online demo</span>
      </div>

      <div className="chatbot-workspace">
        <aside className="chatbot-side-panel">
          <div className="chatbot-side-title">
            <span>✦</span>
            <div>
              <strong>Suggested questions</strong>
              <small>Choose a question to begin</small>
            </div>
          </div>
          <div className="suggestion-list">
            {chatbotSuggestions.map((suggestion) => (
              <button key={suggestion} type="button" onClick={() => sendMessage(suggestion)}>
                {suggestion}<span>↗</span>
              </button>
            ))}
          </div>
          <div className="chatbot-help-note">
            <span>ⓘ</span>
            <p>This is a frontend demo with sample responses. A live AI model and campus database are not connected yet.</p>
          </div>
        </aside>

        <div className="chat-window">
          <div className="chat-window-header">
            <div className="chat-window-avatar">🏛</div>
            <div>
              <strong>Campus Assistant</strong>
              <small>Virtual Campus Support</small>
            </div>
            <button type="button" onClick={clearChat} className="clear-chat-button">Clear chat</button>
          </div>

          <div className="chat-messages" aria-live="polite">
            {messages.map((message) => (
              <div className={`chat-message-row ${message.role}`} key={message.id}>
                {message.role === "assistant" && <div className="message-avatar">🤖</div>}
                <div className="chat-message-content">
                  <div className="chat-bubble">{message.text}</div>
                  <small>{message.role === "user" ? "You" : "Campus Assistant"} · {message.time}</small>
                </div>
                {message.role === "user" && <div className="message-avatar user-avatar">🎓</div>}
              </div>
            ))}
          </div>

          <form className="chat-composer" onSubmit={handleSubmit}>
            <input
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              placeholder="Ask something about your campus..."
              aria-label="Type a campus question"
            />
            <button type="submit" disabled={!draft.trim()} aria-label="Send message">➤ <span>Send</span></button>
          </form>
          <p className="chatbot-disclaimer">Demo responses only · Verify important information with university staff.</p>
        </div>
      </div>
    </section>
  );
}


function FeaturePage({ title, icon, description }) {
  return (
    <section className="panel feature-page">
      <div className="feature-page-icon">{icon}</div>
      <h1>{title}</h1>
      <p>{description}</p>
      <NavLink to="/" className="chat-button">← Back to Dashboard</NavLink>
    </section>
  );
}

function AppContent() {
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const timer = window.setTimeout(() => setShowSplash(false), 2200);
    return () => window.clearTimeout(timer);
  }, []);

  return (
    <>
      <div className="app-layout">
        <Sidebar />
        <main className="main-area">
          <Header />
          <div className="page-content">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/explore" element={<ExploreCampus />} />
              <Route path="/chatbot" element={<Chatbot />} />
              <Route
                path="/appointments"
                element={<FeaturePage title="Appointments" icon="📅" description="The appointment interface will support finding teachers and requesting appointments after the booking functionality is implemented." />}
              />
              <Route
                path="/campus-info"
                element={<FeaturePage title="Campus Information" icon="ⓘ" description="Explore university departments, classrooms, laboratories, library and campus facilities." />}
              />
              <Route
                path="/3d-campus"
                element={<FeaturePage title="3D Virtual Campus" icon="◇" description="The interactive Unity campus will be integrated into this page." />}
              />
              <Route
                path="/notifications"
                element={<FeaturePage title="Announcements & Events" icon="♧" description="Official university announcements and event information will appear here." />}
              />
              <Route
                path="/settings"
                element={<FeaturePage title="Settings" icon="⚙" description="Public interface preferences." />}
              />
              <Route
                path="*"
                element={<FeaturePage title="Page Not Found" icon="ⓘ" description="The requested campus page could not be found." />}
              />
            </Routes>
          </div>
        </main>
      </div>

      {showSplash && (
        <div className="splash-overlay">
          <SplashScreen />
        </div>
      )}
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}
