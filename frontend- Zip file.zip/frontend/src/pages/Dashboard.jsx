
import { Link } from 'react-router-dom'

const campusFeatures = [
  {
    icon: '🏢',
    title: 'Campus Buildings',
    description: 'Explore campus buildings and facilities.',
    color: 'bg-violet-100',
  },
  {
    icon: '📚',
    title: 'Library',
    description: 'Find the library and study spaces.',
    color: 'bg-sky-100',
  },
  {
    icon: '🧪',
    title: 'Computer Labs',
    description: 'Locate computer labs and classrooms.',
    color: 'bg-pink-100',
  },
  {
    icon: '👩‍🏫',
    title: 'Teacher Offices',
    description: 'Find faculty offices and office hours.',
    color: 'bg-emerald-100',
  },
]

function Dashboard() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 md:flex">
      <aside className="bg-white p-5 md:min-h-screen md:w-64 md:border-r md:border-slate-200">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-violet-100 text-2xl">
            🏫
          </div>
          <div>
            <h2 className="font-bold text-violet-800">Virtual Campus</h2>
            <p className="text-xs text-slate-500">Student Portal</p>
          </div>
        </div>

        <nav className="mt-8 flex gap-2 overflow-x-auto md:flex-col">
          <Link
            to="/dashboard"
            className="shrink-0 rounded-xl bg-violet-100 px-4 py-3 text-sm font-semibold text-violet-800"
          >
            🏠 Dashboard
          </Link>
          <a href="#campus" className="shrink-0 rounded-xl px-4 py-3 text-sm hover:bg-slate-100">
            🏢 Campus Information
          </a>
          <a href="#locations" className="shrink-0 rounded-xl px-4 py-3 text-sm hover:bg-slate-100">
            📍 Find Locations
          </a>
          <a href="#appointments" className="shrink-0 rounded-xl px-4 py-3 text-sm hover:bg-slate-100">
            📅 Appointments
          </a>
          <a href="#assistant" className="shrink-0 rounded-xl px-4 py-3 text-sm hover:bg-slate-100">
            💬 AI Assistant
          </a>
        </nav>

        <div className="mt-8 hidden rounded-2xl bg-gradient-to-br from-violet-100 to-sky-100 p-4 md:block">
          <p className="font-semibold">Need campus help?</p>
          <p className="mt-2 text-sm leading-6 text-slate-600">
            Your campus information will be available in one place.
          </p>
        </div>

        <Link
          to="/"
          className="mt-6 inline-block rounded-xl px-4 py-3 text-sm font-medium text-slate-500 hover:bg-slate-100"
        >
          ← Back to Login
        </Link>
      </aside>

      <main className="min-w-0 flex-1 p-5 sm:p-8 lg:p-10">
        <header className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-violet-600">STUDENT PORTAL</p>
            <h1 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">
              Welcome to your campus!
            </h1>
            <p className="mt-3 text-slate-500">
              Explore your campus and find everything you need.
            </p>
          </div>

          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-violet-100 text-xl">
            👤
          </div>
        </header>

        <section className="mt-8 overflow-hidden rounded-3xl bg-gradient-to-r from-violet-600 via-violet-500 to-indigo-500 p-6 text-white shadow-lg shadow-violet-100 sm:p-9">
          <div className="max-w-2xl">
            <span className="rounded-full bg-white/20 px-3 py-1 text-xs font-medium">
              YOUR DIGITAL CAMPUS
            </span>
            <h2 className="mt-5 text-2xl font-bold sm:text-3xl">
              Discover your campus, your way.
            </h2>
            <p className="mt-3 max-w-xl text-sm leading-6 text-violet-100 sm:text-base">
              Explore campus facilities, find classrooms and offices, and get
              ready to experience an interactive virtual campus.
            </p>
            <a
              href="#locations"
              className="mt-6 inline-block rounded-xl bg-white px-5 py-3 text-sm font-semibold text-violet-700 transition hover:bg-violet-50"
            >
              Explore Campus →
            </a>
          </div>
        </section>

        <section id="campus" className="mt-10">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="text-xl font-bold">Campus at a glance</h2>
              <p className="mt-1 text-sm text-slate-500">
                Useful places and facilities
              </p>
            </div>
            <span className="text-sm text-violet-600">Explore facilities</span>
          </div>

          <div id="locations" className="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {campusFeatures.map((feature) => (
              <article
                key={feature.title}
                className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:shadow-md"
              >
                <div className={`flex h-12 w-12 items-center justify-center rounded-xl text-2xl ${feature.color}`}>
                  {feature.icon}
                </div>
                <h3 className="mt-5 font-bold">{feature.title}</h3>
                <p className="mt-2 text-sm leading-6 text-slate-500">
                  {feature.description}
                </p>
                <span className="mt-4 inline-block text-sm font-semibold text-violet-600">
                  View details →
                </span>
              </article>
            ))}
          </div>
        </section>

        <section className="mt-8 grid gap-5 lg:grid-cols-2">
          <article id="assistant" className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-sky-100 text-2xl">
                🤖
              </div>
              <div>
                <h2 className="font-bold">AI Campus Assistant</h2>
                <p className="text-sm text-slate-500">Campus help, all in one place</p>
              </div>
            </div>
            <p className="mt-4 text-sm leading-6 text-slate-600">
              Get ready to ask questions about campus locations, facilities and
              teacher availability.
            </p>
            <button
              type="button"
              onClick={() => alert('AI chatbot integration will be added later.')}
              className="mt-5 rounded-xl bg-sky-500 px-5 py-3 text-sm font-semibold text-white hover:bg-sky-600"
            >
              Open Assistant →
            </button>
          </article>

          <article id="appointments" className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-pink-100 text-2xl">
                📅
              </div>
              <div>
                <h2 className="font-bold">Appointments</h2>
                <p className="text-sm text-slate-500">Plan a visit to an office</p>
              </div>
            </div>
            <p className="mt-4 text-sm leading-6 text-slate-600">
              Appointment booking and office schedules can be connected in a
              future development step.
            </p>
            <button
              type="button"
              onClick={() => alert('Appointment booking will be added later.')}
              className="mt-5 rounded-xl bg-pink-500 px-5 py-3 text-sm font-semibold text-white hover:bg-pink-600"
            >
              View Appointments →
            </button>
          </article>
        </section>

        <footer className="mt-10 border-t border-slate-200 py-6 text-center text-xs text-slate-400">
          AI-Powered Virtual Campus · Frontend Preview
        </footer>
      </main>
    </div>
  )
}

export default Dashboard
